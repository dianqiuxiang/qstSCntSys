package com.qst.scnt.action;


public class BaseAction   {

}
