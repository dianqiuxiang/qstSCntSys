package com.qst.scnt.service;

import com.qst.scnt.model.CustomerInfo;

public interface CustomerInfoService extends BaseService<CustomerInfo> {

}
