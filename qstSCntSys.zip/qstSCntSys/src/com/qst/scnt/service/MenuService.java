package com.qst.scnt.service;

import com.qst.scnt.model.Menu;

public interface MenuService extends BaseService<Menu> {
	
}

