package com.qst.scnt.service;

import com.qst.scnt.model.Cost;
import com.qst.scnt.model.UserInfo;

public interface CostService extends BaseService<Cost> {

}
