package com.qst.scnt.service;

import com.qst.scnt.model.ProductInfo;

public interface ProductInfoService extends BaseService<ProductInfo> {
	

}

