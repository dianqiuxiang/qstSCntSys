package com.qst.scnt.service;

import com.qst.scnt.model.EmployeeInfo;

public interface EmployeeInfoService extends BaseService<EmployeeInfo> {
	
}

