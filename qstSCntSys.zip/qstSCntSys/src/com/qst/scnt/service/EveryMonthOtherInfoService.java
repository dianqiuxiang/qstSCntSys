package com.qst.scnt.service;

import com.qst.scnt.model.EveryMonthOtherInfo;

public interface EveryMonthOtherInfoService extends BaseService<EveryMonthOtherInfo> {
	
}

