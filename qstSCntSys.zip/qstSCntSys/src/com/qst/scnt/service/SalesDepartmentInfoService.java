package com.qst.scnt.service;

import com.qst.scnt.model.SalesDepartmentInfo;

public interface SalesDepartmentInfoService extends BaseService<SalesDepartmentInfo> {
	

}

