package com.qst.scnt.service;

import com.qst.scnt.model.ReceiptInfo;

public interface ReceiptInfoService extends BaseService<ReceiptInfo> {
	
}

