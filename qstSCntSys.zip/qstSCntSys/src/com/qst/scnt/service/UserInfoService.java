package com.qst.scnt.service;

import com.qst.scnt.model.UserInfo;

public interface UserInfoService extends BaseService<UserInfo> {

	public int update();

}

