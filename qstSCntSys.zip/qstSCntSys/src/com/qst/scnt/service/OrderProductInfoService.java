package com.qst.scnt.service;

import com.qst.scnt.model.OrderProductInfo;

public interface OrderProductInfoService extends BaseService<OrderProductInfo> {
	
}

