package com.qst.scnt.service;

import com.qst.scnt.model.ParameterInfo;

public interface ParameterInfoService extends BaseService<ParameterInfo> {
	
}

