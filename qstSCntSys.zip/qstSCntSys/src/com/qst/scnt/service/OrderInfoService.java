package com.qst.scnt.service;

import com.qst.scnt.model.OrderInfo;

public interface OrderInfoService extends BaseService<OrderInfo> {
	
}

