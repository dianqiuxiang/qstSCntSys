package com.qst.scnt.dao;

import com.qst.scnt.model.Menu;

/**
    * Menu	�˵�DAO
    * Wed Dec 27 15:51:34 CST 2017
    */ 


public interface MenuDao  extends BaseDao<Menu> {
	
}

