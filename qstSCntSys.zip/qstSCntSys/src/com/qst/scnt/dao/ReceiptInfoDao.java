package com.qst.scnt.dao;

import com.qst.scnt.model.ReceiptInfo;

/**
    * ReceiptInfo	�տ�DAO
    * Wed Dec 27 15:51:34 CST 2017
    */ 


public interface ReceiptInfoDao  extends BaseDao<ReceiptInfo> {
	

}

