package com.qst.scnt.dao;

import com.qst.scnt.model.ProductInfo;

/**
    * ProductInfo	��ƷDAO
    * Wed Dec 27 15:51:34 CST 2017
    */ 


public interface ProductInfoDao  extends BaseDao<ProductInfo> {
	
}

